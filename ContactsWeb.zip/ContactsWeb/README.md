# Beüzemelés

A ContactDAODBImpl.java fájlban át kell állítani a db elérését vagy a tomcat bin könyvtárába bemásolni a resources/db/contact.db fájlt!
